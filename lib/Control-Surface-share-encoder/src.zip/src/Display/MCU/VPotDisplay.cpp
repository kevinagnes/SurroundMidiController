#include "VPotDisplay.hpp"

BEGIN_CS_NAMESPACE

const float MCU::VPotDisplay::angleSpacing __attribute__((weak)) =
    0.4887; // 28°

END_CS_NAMESPACE