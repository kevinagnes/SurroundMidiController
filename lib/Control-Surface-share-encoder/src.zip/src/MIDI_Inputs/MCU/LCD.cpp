#include "LCD.hpp"

BEGIN_CS_NAMESPACE
namespace MCU {
uint8_t LCDCounter::instances = 0;
}
END_CS_NAMESPACE