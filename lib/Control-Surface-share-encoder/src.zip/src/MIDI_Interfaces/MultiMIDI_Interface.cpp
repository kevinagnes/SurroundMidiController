#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
#include "MultiMIDI_Interface.hpp"
#endif
