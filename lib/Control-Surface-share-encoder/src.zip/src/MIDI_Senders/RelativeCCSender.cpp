#include "RelativeCCSender.hpp"

BEGIN_CS_NAMESPACE

relativeCCmode RelativeCCSender::mode = TWOS_COMPLEMENT;

END_CS_NAMESPACE