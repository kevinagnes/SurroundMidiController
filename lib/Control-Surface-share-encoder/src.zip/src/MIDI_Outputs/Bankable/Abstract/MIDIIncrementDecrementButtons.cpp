#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
#include "MIDIIncrementDecrementButtons.hpp"
#endif
