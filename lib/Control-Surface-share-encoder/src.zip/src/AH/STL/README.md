The files in the `Fallback` folder are from the GCC 7.4.0 STL implementation,
with minimal modifications to get it to compile with Arduino.