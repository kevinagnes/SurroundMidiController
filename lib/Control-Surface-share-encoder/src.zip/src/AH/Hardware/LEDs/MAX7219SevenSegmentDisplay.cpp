#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
// #include "MAX7219SevenSegmentDisplay.hpp" // TODO
#endif