#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
#include <Encoder.h>
#include "EncoderSelector.hpp"
#endif