#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
#include "ProgramChangeSelector.hpp"
BEGIN_CS_NAMESPACE
template class ProgramChangeSelector<3>;
END_CS_NAMESPACE
#endif
